import sys
import random
import heapq
class SuperMinesweeper:
    def remove_from_unrevealed(self, unrevealed):
        newset = []
        for r,c in unrevealed:
            if self.stats[r][c] == -2:
                newset.append((r, c))
        return newset
    def get_cellstats(self, x, y):
        mine_cnt = 0
        unrevealed = []
        cellnumber = self.stats[x][y]
        for a in range(x - self.D, x + self.D + 1):
            for b in range(y - self.D, y + self.D + 1):
                if a < 0 or a >= self.N or b < 0 or b >= self.N:
                    continue
                if x == a and y == b:
                    continue
                d = pow(x - a, 2) + pow(y - b, 2)
                if d > self.D:
                    continue
                if self.stats[a][b] == -2:
                    unrevealed.append((a, b))
                elif self.stats[a][b] == -1:
                    mine_cnt += 1
        mine_remaining = cellnumber - mine_cnt
        if len(unrevealed) > 0 and mine_remaining == 0:
            for r, c in unrevealed:
                print("G " + str(r) + " " + str(c))
                feedback = input().split(" ")
                self.stats[r][c] = int(feedback[0])
        return unrevealed, mine_remaining, mine_cnt
    def build_heap(self, unrevealed):
        heap = []
        random.shuffle(unrevealed)
        for r, c in unrevealed:
            _, _, mine = self.get_cellstats(r, c)
            heapq.heappush(heap, (-mine, (r, c)))

    def adjust_common_mine_cells(self):
        for x in range(self.N):
            for y in range(self.N):
                if self.stats[x][y] > 0:
                    for a in range(x - 2*self.D, x + 2*self.D + 1):
                        for b in range(y - 2*self.D, y + 2*self.D + 1):
                            if a < 0 or a >= self.N or b < 0 or b >= self.N:
                                continue
                            if x == a and x == b:
                                continue
                            un1, mine_remaining1, _ = self.get_cellstats(x, y)
                            un2, mine_remaining2, _ = self.get_cellstats(a, b)

                            common_unrevealed = un1.intersection(un2)

                            if len(common_unrevealed) > 0 and ( (mine_remaining1 == len(common_unrevealed)) or (mine_remaining2 == len(common_unrevealed) )):
                                for r, c in common_unrevealed:
                                    self.stats[r][c] = -1

    def place_mines(self, x, y):
        unrevealed, mine_remaining, _ = self.get_cellstats(x, y)
        if len(unrevealed) == mine_remaining:
            for r,c in unrevealed:
                self.stats[r][c] = -1
        elif int(0.6*len(unrevealed)) >= mine_remaining:
            random.shuffle(unrevealed)
            for i in range(0, mine_remaining):
                r,c = unrevealed[i]
                self.stats[r][c] = -1

    def zero_propagate(self, r, c):
        queue = [(r, c)]
        while queue:
            x, y = queue.pop(0)
            for a in range(x-self.D, x+self.D+1):
                for b in range(y-self.D, y+self.D+1):
                    if a<0 or a >= self.N or b<0 or b>= self.N:
                        continue
                    if x==a and y==b:
                        continue
                    d = pow(x-a, 2) + pow(y-b, 2)
                    if d > self.D:
                        continue
                    if self.stats[a][b] != -2:
                        continue
                    print("G "+str(a)+" "+str(b))
                    temp = input().split(" ")
                    value = int(temp[0])
                    runtime = int(temp[1])
                    if value == 0:
                        queue.append((a, b))
                    self.stats[a][b] = value
    def __init__(self, N, M, D, inputCell):
        self.N=N
        self.M=M
        self.D=D
        self.stats =[ [-2 for j in range(N)] for i in range(N)]

        self.Grid=[[-1 for r in range(N)] for c in range(N)]
        temp=inputCell.split()
        r=int(temp[0])
        c=int(temp[1])
        self.Grid[r][c]=0
        self.stats[r][c] = 0

        self.zero_propagate(r,c)
        self.lastR=0
        self.lastC=-1


N = int(input())
M = int(input())
D = int(input())
inputCell = input()
 
prog = SuperMinesweeper(N, M, D, inputCell)
maxhit = int(0.5*M)
cnt = 0
unrevealed = []
for i in range(N):
    for j in range(N):
        if prog.stats[i][j] == -2:
            unrevealed.append((i, j))
size = len(unrevealed)
mine_remained = M
while cnt < maxhit or len(unrevealed) > 0:
    if mine_remained <= len(unrevealed):
        break
    for iter in range(0, 5):
        prog.adjust_common_mine_cells()
        for i in range(N):
            for j in range(N):
                if prog.stats[i][j] > 0:
                    prog.place_mines(i, j)
    unrevealed = prog.remove_from_unrevealed(unrevealed)
    size = len(unrevealed)
    heap = prog.build_heap(unrevealed)
    cellmap = dict()
    for ind, r, c in enumerate(unrevealed):
        cellmap[(r, c)] = ind
    _, a, b = heapq.heappop(heap)
    index = cellmap[(a, b)]   #random.randint(0, size-1)
    #a, b = unrevealed[index]

    tmp = unrevealed[0]
    unrevealed[0] = unrevealed[index]
    unrevealed[index] = tmp
    r, c = unrevealed[0]
    unrevealed.pop(0)
    size-=1
    print("G "+str(r)+" "+str(c))
    feedback = input()
    if feedback[0:5]=="BOOM!":
        cnt += 1
        mine_remained -= 1
        prog.stats[r][c] = -1
    else:
        temp = feedback.split(" ")
        value = int(temp[0])
        runtime = int(temp[1])
        if value == 0:
            prog.stats[r][c] = 0
            prog.zero_propagate(r, c)
        else:
            prog.stats[r][c] = value


'''for iter in range(500):
    for i in range(N):
        for j in range(N):
            if prog.stats[i][j] > 0:
                prog.place_mines(i, j)'''
print("STOP")
sys.stdout.flush()
