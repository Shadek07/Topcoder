import sys
import random
import heapq
from collections import defaultdict
import copy
class SuperMinesweeper:
    def remove_from_unrevealed(self, unrevealed):
        newset = []
        for r,c in unrevealed:
            if self.stats[r][c] == -2:
                newset.append((r, c))
        return newset
    def find_neighbors(self):
        for x in range(self.N):
            for y in range(self.N):
                for a in range(x - self.D, x + self.D + 1):
                    for b in range(y - self.D, y + self.D + 1):
                        if a < 0 or a >= self.N or b < 0 or b >= self.N:
                            continue
                        if x == a and x == b:
                            continue
                        d = pow(x - a, 2) + pow(y - b, 2)
                        if d > self.D:
                            continue
                        self.neighbors[(x, y)].append((a, b))

    def get_cellstats(self, x, y):
        mine_found = 0
        unrevealed = []
        cellnumber = self.stats[x][y]
        cnt_cells_withnumber = 0
        neighbors = self.neighbors[(x, y)]
        sum_value = 0
        for a, b in neighbors:
            if self.stats[a][b] == -2:
                unrevealed.append((a, b))
            elif self.stats[a][b] == -1:
                mine_found += 1
            elif self.stats[a][b] >= 0:
                sum_value += self.stats[a][b]
        mine_remaining = cellnumber - mine_found
        if len(unrevealed) > 0 and mine_remaining == 0:
            for r, c in unrevealed:
                if self.stats[r][c] != -2:
                    continue
                print("G " + str(r) + " " + str(c))
                feedback = input().split(" ")
                if feedback[0][0:5] == "BOOM!":
                    self.stats[r][c] = -1
                    self.minehit += 1
                    self.mineremained -= 1
                    self.update_neighbors_after_mine_find(r, c)
                else:
                    self.stats[r][c] = int(feedback[0])
                    self.place_mines(r, c)
        return unrevealed, mine_remaining, mine_found, sum_value
    def find_next_cell(self, unrevealed):
        heap = []
        random.shuffle(unrevealed)
        unrevealed_minvaluewise_dict = dict()
        min_sumvalue= 1000000
        for r, c in unrevealed:
            neighbor_unrevealed, _, mine_found, sumvalue = self.get_cellstats(r, c)

            if sumvalue not in unrevealed_minvaluewise_dict:
                unrevealed_minvaluewise_dict[sumvalue] = [(r, c)]
            else:
                unrevealed_minvaluewise_dict[sumvalue].append((r, c))
            #heapq.heappush(heap, (-len(unrevealed1), mine_found, cnt_numbercells, (r, c)))
            if min_sumvalue > sumvalue:
                min_sumvalue = sumvalue
        if min_sumvalue < 1000000:
            tmp = unrevealed_minvaluewise_dict[min_sumvalue]
            return tmp[random.randint(0, len(tmp)-1)]
        else:
            return unrevealed[0]

    def adjust_common_mine_cells(self):
        for x in range(self.N):
            for y in range(self.N):
                if self.stats[x][y] > 0:
                    for a in range(x - 2*self.D, x + 2*self.D + 1):
                        for b in range(y - 2*self.D, y + 2*self.D + 1):
                            if a < 0 or a >= self.N or b < 0 or b >= self.N:
                                continue
                            if x == a and x == b:
                                continue
                            un1, mine_remaining1, _, _ = self.get_cellstats(x, y)
                            un2, mine_remaining2, _, _ = self.get_cellstats(a, b)

                            common_unrevealed = set(un1).intersection(un2)

                            if len(common_unrevealed) > 0 and ( (mine_remaining1 == len(common_unrevealed)) or (mine_remaining2 == len(common_unrevealed) )):
                                for r, c in common_unrevealed:
                                    self.stats[r][c] = -1

    def update_neighbors_after_mine_find(self, r, c): #r, c is mine_location
        neighbors = self.neighbors[(r, c)]
        for a, b in neighbors:
            if self.stats[a][b] > 0:
                if (a, b) not in self.cellstat_withnumber:
                    unrevealed, mine_remaining, mine_found, cnt_cells_withnumber = self.get_cellstats(a, b)
                    self.cellstat_withnumber[(a, b)] = (set(unrevealed), mine_remaining, mine_found, cnt_cells_withnumber)

                unrevealed, mine_remaining, mine_found, cnt_cells_withnumber = self.cellstat_withnumber[(a, b)]
                if (r, c) in unrevealed:
                    unrevealed.remove((r, c))
                    mine_remaining -= 1
                    mine_found += 1
                self.cellstat_withnumber[(a, b)] = (unrevealed, mine_remaining, mine_found, cnt_cells_withnumber)
                if len(unrevealed) > 0 and mine_remaining == 0:
                    tmp = list(unrevealed)
                    for r1, c1 in tmp:
                        self.stats[r1][c1] = -1
                        self.update_neighbors_after_mine_find(r1, c1)


    def place_mines(self, x, y): #x,y is a number_cell
        unrevealed, mine_remaining, mine_found, cnt_cells_withnumber = self.get_cellstats(x, y)
        self.cellstat_withnumber[(x, y)] = (set(unrevealed), mine_remaining, mine_found, cnt_cells_withnumber)
        if len(unrevealed) == mine_remaining:
            for r,c in unrevealed:
                self.stats[r][c] = -1
                self.update_neighbors_after_mine_find(r, c)
        elif int(0.8*len(unrevealed)) >= mine_remaining:
            random.shuffle(unrevealed)
            for i in range(0, mine_remaining):
                r,c = unrevealed[i]
                self.stats[r][c] = -1
                self.update_neighbors_after_mine_find(r, c)

    def zero_propagate(self, r, c):
        queue = [(r, c)]
        while queue:
            x, y = queue.pop(0)
            neighbors = self.neighbors[(x, y)]
            for a, b in neighbors:
                if self.stats[a][b] != -2:
                    continue
                print("G "+str(a)+" "+str(b))
                temp = input().split(" ")
                value = int(temp[0])
                runtime = int(temp[1])
                if value == 0:
                    queue.append((a, b))
                else:
                    unrevealed, mine_remaining, mine_found, cnt_cells_withnumber = self.get_cellstats(a,b)
                    self.cellstat_withnumber[(a, b)] = (set(unrevealed), mine_remaining, mine_found, cnt_cells_withnumber)
                    self.place_mines(a, b)
                self.stats[a][b] = value
    def __init__(self, N, M, D, inputCell):
        self.N=N
        self.M=M
        self.D=D
        self.stats =[ [-2 for j in range(N)] for i in range(N)]

        self.Grid=[[-1 for r in range(N)] for c in range(N)]
        temp=inputCell.split()
        r=int(temp[0])
        c=int(temp[1])
        self.Grid[r][c] = 0
        self.stats[r][c] = 0
        self.minehit = 0
        self.mineremained = M
        self.neighbors = defaultdict(lambda: [])
        self.find_neighbors()
        self.cellstat_withnumber = dict()
        self.zero_propagate(r, c)



N = int(input())
M = int(input())
D = int(input())
inputCell = input()

#f = open("output.txt", "w")
 
prog = SuperMinesweeper(N, M, D, inputCell)


maxhit = int(0.07*M)

if N > 40:
    maxhit = int(0.03*M)
cnt = 0
unrevealed = []
for i in range(N):
    for j in range(N):
        if prog.stats[i][j] == -2:
            unrevealed.append((i, j))
size = len(unrevealed)
mine_remained = M

#f.write(str(len(heap)) + '\n')
#f.write(str(size) + '\n')
#f.write(str(prog.iter) + '\n')

'''for i in range(N):
            for j in range(N):
                if prog.stats[i][j] > 0:
                    prog.place_mines(i, j)'''
while (prog.minehit < maxhit) or (len(unrevealed) > 0):
    if mine_remained >= len(unrevealed):
        break
    #prog.adjust_common_mine_cells()

    #items = prog.cellstat_withnumber.items()

    items = {k: v for k, v in prog.cellstat_withnumber.items() if v}

    for key in prog.cellstat_withnumber.copy():
        if not prog.cellstat_withnumber[key]:
            prog.cellstat_withnumber.pop(key)
        r, c = key
        prog.place_mines(r, c)
        
    unrevealed = prog.remove_from_unrevealed(unrevealed)
    size = len(unrevealed)
    if size == 0:
        break

    r, c = prog.find_next_cell(unrevealed)

    size -= 1
    print("G "+str(r)+" "+str(c))
    feedback = input()
    if feedback[0:5] == "BOOM!":
        prog.minehit += 1
        prog.mineremained -= 1
        prog.stats[r][c] = -1
        prog.update_neighbors_after_mine_find(r, c)
        #break
    else:
        temp = feedback.split(" ")
        value = int(temp[0])
        runtime = int(temp[1])
        if value == 0:
            prog.stats[r][c] = 0
            prog.zero_propagate(r, c)
        else:
            prog.stats[r][c] = value

    #f.write("exited" + "\n")

'''for iter in range(500):
    for i in range(N):
        for j in range(N):
            if prog.stats[i][j] > 0:
                prog.place_mines(i, j)'''
print("STOP")
#f.close()
sys.stdout.flush()

