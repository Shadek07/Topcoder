import sys
from typing import List
import random

class LostTreasureHunter :
    def init(self, treasureValue : int, stepCost : int, numChambers : int, maxTreasure : int) :
        self.treasureValue = treasureValue 
        self.stepCost = stepCost 
        self.numChambers = numChambers 
        self.maxTreasure = maxTreasure
        self.numStep = 0
        self.edges = dict()
        self.adj = dict()
        self.treasures = [0 for i in range(self.numChambers)] #treasure count in each chamber currently
        self.pathCounts = [0 for i in range(self.numChambers)]
        self.chamberCnt = 0
        self.total_treasures = 0
        self.history = []
        self.cur = -1 
        self.treasureTaken = 0
    def addVertex(self, treasureCount: int, pathCount: int):
        self.treasures[self.chamberCnt] = treasureCount
        self.pathCounts[self.chamberCnt] = pathCount
        if len(self.history) > 0:
            self.adj[self.chamberCnt] = [self.history[-1]]
            self.adj[self.history[-1]].append(self.chamberCnt)
        else:
            self.adj[0] = []
        self.addToHistory(self.chamberCnt)
        self.collectTreasures(self.chamberCnt)
        self.cur = self.chamberCnt
        self.chamberCnt+=1
        
    def collectTreasures(self, chamber: int):
        t = min(self.treasures[chamber], self.maxTreasure)
        self.total_treasures += t
        self.treasures[chamber] -= t
        if t>0:
            print(t)
            self.treasureTaken = t
        else:
            print(-1)
            self.treasureTaken = -1
        #sys.stdout.flush()

        
    def addToHistory(self, chamber: int):
        self.history.append(chamber)
    def printPath(self, ind: int):
        if self.treasureTaken != -1:
            print(ind)
        sys.stdout.flush()

    def processChamber(self, t: int, p: int):
        existing = []
        for k, v in self.adj.items():
            if self.cur != k and self.treasures[k] == t and self.pathCounts[k] == p:
                existing.append(k)
        if len(existing) == 0:
            if self.chamberCnt < self.numChambers:         
                self.addVertex(t, p)
                self.printPath(random.randint(0, self.pathCounts[self.cur]-1))
                
            else:
                self.treasureTaken = -1
                print(-1)
                self.printPath(-1)
                
        else:
            candidates = []
            for k in existing:
                candidates.append((-(self.pathCounts[k]-len(self.adj[k])), k))
            candidates = sorted(candidates)
            self.cur = candidates[0][1]
            self.addToHistory(self.cur)
            self.collectTreasures(self.cur)
            sz = len(self.adj[self.cur])            
            if sz == self.pathCounts[self.cur]:
                self.printPath(random.randint(0, sz-1))
            else:
                self.printPath(sz)

    def finalvalue(self):
        return self.total_treasures*self.treasureValue - self.stepCost*self.numStep

    def findSolution(self, treasureCount : int, pathCount : int, time : str) :
        self.processChamber(treasureCount, pathCount)
        self.numStep += 1

treasureValue = int(input())
stepCost = int(input())
numChambers = int(input())
maxTreasure = int(input())

hunter = LostTreasureHunter()
hunter.init(treasureValue,stepCost,numChambers,maxTreasure)
curvalue = 0
#print('here')
while hunter.numStep < 1000:
    treasureCount = int(input())
    pathCount = int(input())
    time = input()

    hunter.findSolution(treasureCount,pathCount,time)
    nextvalue = hunter.finalvalue()
    if nextvalue < curvalue*0.8:
        break    
    curvalue = nextvalue
    #print('curvalue', curvalue)


