import sys
from collections import defaultdict
import copy

class LineGame:
    def __init__(self, N, C):
        self.N = N
        self.cells = N*N
        self.C = C
        self.nextBalls = [0] * 3
        self.dist = [ [float('inf') for j in range(self.N)] for i in range(self.N)]

        self.dr = [0,1,0,-1]
        self.dc = [-1,0,1,0]    
        self.empty_cells_around = [ [0 for j in range(N)] for i in range(N)]
        self.segment_scores = None
        self.powers = dict()
        for i in range(-100,100):
            self.powers[i] = pow(self.N,i)
        m = N-5+1
        self.diag = []
        for i in range(1,m+1):
            self.diag.append(i)
        for i in range(m-2,0,-1):
            self.diag.append(i)

    def find_emptycells_around(self):
        self.empty_cells_around = [ [0 for j in range(N)] for i in range(N)]
        for i in range(self.N):
            for j in range(self.N):
                visit = dict()
                q = [(i,j)]
                while q:
                    a, b = q[0]
                    q.pop(0)
                    visit[(a,b)] = 1
                    for k in range(4):
                        x, y =a+self.dr[k], b+self.dc[k]
                        if x>=0 and x<self.N and y>= 0 and y<self.N:
                            if self.grid[x][y] == 0 and (x,y) not in visit:
                                visit[(x,y)]=  1
                                q.append((x,y))
                self.empty_cells_around[i][j] = len(visit)
                    
                    
    def getStreak(self, a, b, dx, dy):
        colorcnt, color = 0, 0
        cnt = 0
        while cnt < self.N:
            a, b = a+dx, b+dy
            if a<0 or a>=self.N or b<0 or b>=self.N:
                break
            if color != 0 and self.grid[a][b] != 0 and  color != self.grid[a][b]:
                break
            if color == 0 and self.grid[a][b] == 0:
                return -9999, 0
            if self.grid[a][b] != 0:
                color = self.grid[a][b]
                colorcnt += 1
            cnt += 1                
        return colorcnt, color
            
    def getInput(self):
        self.grid = [[0 for j in range(self.N)] for i in range(self.N)]
        for i in range(self.N):
            for j in range(self.N):
                self.grid[i][j] = int(input())

        for k in range(3): 
            self.nextBalls[k] = int(input())	
        self.elapsed = int(input())

    def isFarther(self, ex, ey, a, b):
        if ex-a == 0 or ey-b == 0:
            return abs(ex-a)+abs(ey-b)>4
        elif abs(ex-a) == abs(ey-b):
            return abs(ex-a) > 4
        return True 

    def update_dominant(self, maxcount, color, cnt, cl):
        if cnt > maxcount:
            return (cnt, cl)
        else:
            return (maxcount, color)

    def componentVisit(self, component_num, a, b):
        self.component[component_num].add((a,b))
        self.cell_to_component[(a,b)] = component_num
        for k in range(4):
            x,y = a+self.dr[k], b+self.dc[k]
            if x>=0 and x<self.N and y>=0 and y<self.N and self.grid[x][y] == 0 and ((x,y) not in self.component[component_num]):
                self.componentVisit(component_num, x,y)
    

    def isConnected(self, a, b, c, d):
        adj_empty = []
        for k in range(4):
            x, y = a+self.dr[k], b+self.dc[k]
            if x>=0 and x<self.N and y>=0 and y<self.N and self.grid[x][y]==0:
                adj_empty.append((x,y))
        c = self.cell_to_component[(c,d)]
        for x,y in adj_empty:
            if self.cell_to_component[(x,y)] == c:
                return True
        return False
    
    def makeConnected(self):
        self.component = defaultdict(set)
        self.cell_to_component = dict()
        self.visited = dict()         
        self.component_cnt = 0
        for i in range(self.N):
            for j in range(self.N):
                if self.grid[i][j] == 0 and (i,j) not in self.visited:
                    self.componentVisit(self.component_cnt, i,j)
                    for a, b in self.component[self.component_cnt]:
                        self.visited[(a,b)] = 1
                    self.component_cnt+=1
        self.same = defaultdict(list)            
        for i in range(self.N):
            for j in range(self.N):
                if self.grid[i][j] != 0:
                    self.same[self.grid[i][j]].append((i,j))
#(N-4)*N
    def getHorizontalSegment(self, i,j):
        return (self.N-4)*i+j
    def getVerticalSegment(self, i,j):
        return (self.N-4)*self.N + (self.N-4)*j+i

    def getForwardDiagonalSegment(self, i, j):
        pass

    def getSegmentScore(self, a, b, dx, dy):
        cnt = 0
        freq = defaultdict(lambda:0)
        empties = []
        while cnt < 5:
            if self.grid[a][b] != 0:
                freq[self.grid[a][b]]+=1
            else:
                empties.append((a,b))
            cnt += 1                
            a, b = a+dx, b+dy
        arr = []
        max_cnt = -1
        dominant_color =0
        for k,v in freq.items():
            arr.append(v)
            if v>max_cnt:
                max_cnt = v
                dominant_color = k
        arr = sorted(arr)[::-1]
        if len(arr)>0:
#return pow(N, arr[0]-4*sum(arr[1:]))
            '''accessible_dominant = 0
            for domi_x, domi_y in self.same[dominant_color]:
                if any([self.isFarther(domi_x,domi_y,p,q) for p,q in empties]) and any([ self.isConnected(domi_x, domi_y,p,q) for p,q in empties]):
                    accessible_dominant += 1'''
            '''extra = len(self.same[dominant_color])-max_cnt'''
            return self.powers[(arr[0]-4*sum(arr[1:]))]# + self.powers[accessible_dominant-(5-sum(arr))]
        return 0      

    def getBaseScores(self):
        self.segment_scores = [0]*(self.N-4)*2*self.N
        self.diagonal = dict()
        for i in range(self.N):
            for j in range(self.N):
                if j+4<self.N:
                    self.segment_scores[self.getHorizontalSegment(i,j)] = self.getSegmentScore(i,j,0,1)
                if i+4<self.N:
                    self.segment_scores[self.getVerticalSegment(i,j)] = self.getSegmentScore(i,j,1,0)
                if i+4<self.N and j-4>=0:
                    self.diagonal[str(i)+"_"+str(j)+"f"] = self.getSegmentScore(i,j,1,-1)

                if i+4<self.N and j+4<self.N:
                    self.diagonal[str(i)+"_"+str(j)+"b"] = self.getSegmentScore(i,j,1,1)
    def boardEvaluate(self, sx, sy, dx, dy):
#        grid = copy.deepcopy(self.grid)
        self.grid[sx][sy], self.grid[dx][dy] = self.grid[dx][dy], self.grid[sx][sy]
        score = sum(self.segment_scores) 
        for k,v in self.diagonal.items():
            score += v
        for x, y in [(sx,sy),(dx,dy)]:
            for i in range(y-4,y+1):
                if i<0:
                    continue
                if i+4>=self.N:
                    continue
                hind = self.getHorizontalSegment(x,i)
                score -= self.segment_scores[hind]
                score += self.getSegmentScore(x,i,0,1)
            for i in range(x-4,x+1):
                if i<0:
                    continue
                if i+4>=self.N:
                    continue
                vind = self.getVerticalSegment(i,y)
                score -= self.segment_scores[vind]
                score += self.getSegmentScore(i,y,1,0)
            #forward diagonal score adjustment
            for k in range(0,5):
                a,b = x-k, y+k
                if a<0 or b>=self.N:
                    break
                if a+4>=self.N or b-4<0:
                    continue
                key = str(a)+"_"+str(b)+"f"
                score -= self.diagonal[key]
                score += self.getSegmentScore(a,b,1,-1)
            #backward \ diagonal score adjustment
            for k in range(0,5):
                a,b = x-k,y-k
                if a<0 or b<0:
                    break
                if a+4>=self.N or b+4>= self.N:
                    continue
                key = str(a)+"_"+str(b)+"b"
                score -= self.diagonal[key]
                score += self.getSegmentScore(a,b,1,1)
            
        self.grid[sx][sy], self.grid[dx][dy] = self.grid[dx][dy], self.grid[sx][sy]
        return score

    def makeMove(self):
        #self.runFloydWarshall()
        self.makeConnected()
#        self.find_emptycells_around()
        arr = []

        self.dir = [(0,-1), (0,1),(-1,0),(1,0),(-1,1),(1,-1), (-1,-1),(1,1)]
        self.dir2 = [(0,1), (1,0), (-1,1), (1,1)]
        self.reachable = dict()
        self.getBaseScores()
        for i in range(self.cells):
            for j in range(self.cells):
                if i==j:
                    continue
                a, b = i//self.N, int(i%self.N)
                x,y = j//self.N, int(j%self.N)
                if self.grid[a][b] != 0 and self.grid[x][y] == 0 and self.isConnected(a, b, x, y): 
                    arr.append((self.boardEvaluate(a,b,x,y),a,b,x,y))
        arr = sorted(arr, key=lambda x:(-x[0]))                    
        return str(arr[0][1]) + " "+str(arr[0][2])+" "+str(arr[0][3])+" "+str(arr[0][4])


N = int(input())
C = int(input())

EMPTY = 0
game = LineGame(N,C)
for i in range(1000):
    game.getInput()
    move=game.makeMove()
    print(move)
    sys.stdout.flush()
    if self.elapsed >= 9500:
        break

