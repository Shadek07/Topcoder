import sys
from collections import defaultdict
from collections import Counter
import copy

class LineGame:
    def __init__(self, N, C):
        self.N = N
        self.cells = N*N
        self.C = C
        self.nextBalls = [0] * 3
        self.dist = [ [float('inf') for j in range(self.N)] for i in range(self.N)]

        self.dr = [0,1,0,-1]
        self.dc = [-1,0,1,0]    
        self.empty_cells_around = [ [0 for j in range(N)] for i in range(N)]
        self.segment_scores = None
        self.powers = dict()
        for i in range(-100,100):
            self.powers[i] = pow(self.N,i)
        self.diagonal_percentage = 1
        self.elapsed = None
        self.move_num = 0
                    
    def getStreak(self, a, b, dx, dy):
        colorcnt, color = 0, 0
        cnt = 0
        while cnt < self.N:
            a, b = a+dx, b+dy
            if a<0 or a>=self.N or b<0 or b>=self.N:
                break
            if color != 0 and self.grid[a][b] != 0 and  color != self.grid[a][b]:
                break
            if color == 0 and self.grid[a][b] == 0:
                return -9999, 0
            if self.grid[a][b] != 0:
                color = self.grid[a][b]
                colorcnt += 1
            cnt += 1                
        return colorcnt, color
            
    def getInput(self):
        self.grid = [[0 for j in range(self.N)] for i in range(self.N)]
        self.balls = []
        self.empty_slots = []
        for i in range(self.N):
            for j in range(self.N):
                self.grid[i][j] = int(input())
                if self.grid[i][j] == 0:
                    self.empty_slots.append((i,j))
                else:
                    self.balls.append((i,j))

        for k in range(3): 
            self.nextBalls[k] = int(input())	
        self.elapsed = int(input())

    def isFarther(self, ex, ey, a, b):
        if ex-a == 0 or ey-b == 0:
            return abs(ex-a)+abs(ey-b)>4
        elif abs(ex-a) == abs(ey-b):
            return abs(ex-a) > 4
        return True 

    def update_dominant(self, maxcount, color, cnt, cl):
        if cnt > maxcount:
            return (cnt, cl)
        else:
            return (maxcount, color)

    def componentVisit(self, component_num, a, b):
        self.component[component_num].add((a,b))
        self.cell_to_component[(a,b)] = component_num
        for k in range(4):
            x,y = a+self.dr[k], b+self.dc[k]
            if x>=0 and x<self.N and y>=0 and y<self.N and self.grid[x][y] == 0 and ((x,y) not in self.component[component_num]):
                self.componentVisit(component_num, x,y)
    

    def isConnected(self, a, b, c, d):
        adj_empty = []
        for k in range(4):
            x, y = a+self.dr[k], b+self.dc[k]
            if x>=0 and x<self.N and y>=0 and y<self.N and self.grid[x][y]==0:
                adj_empty.append((x,y))
        if self.grid[a][b] == 0:
            return False
        if (c,d) not in self.cell_to_component:
            return False
        c = self.cell_to_component[(c,d)]
        for x,y in adj_empty:
            if self.cell_to_component[(x,y)] == c:
                return True
        return False
    
    def makeConnected(self):
        self.component = defaultdict(set)
        self.cell_to_component = dict()
        self.visited = dict()         
        self.component_cnt = 0
        for i in range(self.N):
            for j in range(self.N):
                if self.grid[i][j] == 0 and (i,j) not in self.visited:
                    self.componentVisit(self.component_cnt, i,j)
                    for a, b in self.component[self.component_cnt]:
                        self.visited[(a,b)] = 1
                    self.component_cnt+=1
        self.same = defaultdict(list)            
        for i in range(self.N):
            for j in range(self.N):
                if self.grid[i][j] != 0:
                    self.same[self.grid[i][j]].append((i,j))
#(N-4)*N
    def getHorizontalSegment(self, i,j):
        return (self.N-4)*i+j

    def getVerticalSegment(self, i,j):
        return (self.N-4)*self.N + (self.N-4)*j+i

    def isAlone(self,a,b):
        dx = [ -1, -1, -1, 0, 0, 1, 1, 1]
        dy = [ -1, 0, 1, -1, 1, -1, 0, 1 ]
        for k in range(8):
            x,y=a+dx[k],b+dy[k]
            if x>=0 and x<self.N and y>=0 and y<self.N and self.grid[a][b] == self.grid[x][y]:
                return False
        return True

    def isBridgeCell(self,a,b):
        set1 = set()
        set2 = set()
        for dx,dy in [(0,1),(0,-1)]:
            x,y=a+dx,b+dy
            if x>=0 and x<self.N and y>=0 and y<self.N:
                set1.add(self.grid[x][y])               
        for dx,dy in [(-1,0),(1,0)]:
            x,y=a+dx,b+dy
            if x>=0 and x<self.N and y>=0 and y<self.N:
                set2.add(self.grid[x][y])               
        set1 = list(set1)
        set2 = list(set2)
        
        return len(set1) == 2 and len(set2) == 1
    def getSegmentScore(self, a, b, dx, dy):
        cnt = 0
        freq = defaultdict(lambda:0)
        empties = []
        while cnt < 5:
            if self.grid[a][b] != 0:
                freq[self.grid[a][b]]+=1
            else:
                empties.append((a,b))
            cnt += 1                
            a, b = a+dx, b+dy
        arr = []
        max_cnt = -1
        dominant_color =0
        for k,v in freq.items():
            arr.append(v)
            if v>max_cnt:
                max_cnt = v
                dominant_color = k
        if len(arr)>0:
            arr = sorted(arr)[::-1]
            '''fillup = 0
            taken = set()#find out how many empty cells in current segment can be filled up by dominant color
            for ex,ey in empties:            
                for a,b in self.same[dominant_color]:
                    if self.isFarther(ex, ey, a,b) and self.isConnected(ex,ey,a,b) and self.isAlone(a,b) and (a,b) not in taken:
                        taken.add((a,b))
                        fillup+=1
                        break'''
#            counter = Counter(self.nextBalls)
#            dominant_in_nextballs = 0 if dominant_color not in counter else counter[dominant_color]
#next_score =(min(len(empties), dominant_in_nextballs))/self.component_cnt
            # +min(15, len(self.same[dominant_color]))+dominant_in_nextballs           
            return self.powers[arr[0]-4*sum(arr[1:])] #+ nextball_score*(1.0/self.component_cnt) # + self.powers[accessible_dominant-(5-sum(arr))]
        return 0      

    def getBaseScores(self):
        self.segment_scores = [0]*(self.N-4)*2*self.N
        self.diagonal = dict()
        for i in range(self.N):
            for j in range(self.N):
                if j+4<self.N:
                    self.segment_scores[self.getHorizontalSegment(i,j)] = self.getSegmentScore(i,j,0,1)
                if i+4<self.N:
                    self.segment_scores[self.getVerticalSegment(i,j)] = self.getSegmentScore(i,j,1,0)
                '''if i+4<self.N and j-4>=0:
                    self.diagonal[str(i)+"_"+str(j)+"f"] = self.getSegmentScore(i,j,1,-1)*self.diagonal_percentage

                if i+4<self.N and j+4<self.N:
                    self.diagonal[str(i)+"_"+str(j)+"b"] = self.getSegmentScore(i,j,1,1)*self.diagonal_percentage'''

    def boardEvaluate(self, sx, sy, dx, dy):
        self.grid[sx][sy], self.grid[dx][dy] = self.grid[dx][dy], self.grid[sx][sy]
        score = sum(self.segment_scores) 
        '''for k,v in self.diagonal.items():
            score += v'''
        for x, y in [(sx,sy),(dx,dy)]:
            for i in range(y-4,y+1):
                if i<0:
                    continue
                if i+4>=self.N:
                    break
                hind = self.getHorizontalSegment(x,i)
                score -= self.segment_scores[hind]
                score += self.getSegmentScore(x,i,0,1)
            for i in range(x-4,x+1):
                if i<0:
                    continue
                if i+4>=self.N:
                    break
                vind = self.getVerticalSegment(i,y)
                score -= self.segment_scores[vind]
                score += self.getSegmentScore(i,y,1,0)
            #forward diagonal score adjustment
            '''for k in range(0,5):
                a,b = x-k, y+k
                if a<0 or b>=self.N:
                    break
                if a+4>=self.N or b-4<0:
                    continue
                key = str(a)+"_"+str(b)+"f"
                score -= self.diagonal[key]
                score += self.getSegmentScore(a,b,1,-1)*self.diagonal_percentage
            #backward \ diagonal score adjustment
            for k in range(0,5):
                a,b = x-k,y-k
                if a<0 or b<0:
                    break
                if a+4>=self.N or b+4>= self.N:
                    continue
                key = str(a)+"_"+str(b)+"b"
                score -= self.diagonal[key]
                score += self.getSegmentScore(a,b,1,1)*self.diagonal_percentage'''
        self.grid[sx][sy], self.grid[dx][dy] = self.grid[dx][dy], self.grid[sx][sy]
        return score

    def makeMove(self):
        self.makeConnected()
        arr = []

        if self.elapsed > 9300 or (self.move_num>0 and self.move_num%10 == 0):
            for _,a,b,x,y in self.arr:
                if self.isConnected(a,b,x,y):
                    return str(a) + " "+str(b)+" "+str(x)+" "+str(y)

        self.getBaseScores()
        for a,b  in self.balls: 
            for x,y in self.empty_slots:
                if self.isConnected(a, b, x, y): 
                    arr.append((self.boardEvaluate(a,b,x,y),a,b,x,y))
        arr = sorted(arr, key=lambda x:(-x[0]))                    
        self.arr = arr
        return str(arr[0][1]) + " "+str(arr[0][2])+" "+str(arr[0][3])+" "+str(arr[0][4])


N = int(input())
C = int(input())

game = LineGame(N,C)
for i in range(1000):
    game.getInput()
    move=game.makeMove()
    print(move)
    game.move_num += 1
    sys.stdout.flush()

