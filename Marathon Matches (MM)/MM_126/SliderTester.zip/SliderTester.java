import java.awt.*;
import java.awt.geom.*;
import com.topcoder.marathon.*;


public class SliderTester extends MarathonAnimatedVis {
    //parameter ranges
    private static final int minN = 10, maxN = 30;
    private static final int minC = 2, maxC = 9;
    private static final int minH = 1, maxH = 10;
    private static final double minF = 0.2, maxF = 0.8;

    //Inputs
    private int N;      //grid size
    private int C;      //number of colors
    private int H;      //number of holes
    private double F;   //fill rate

    //Manual play
    private int lastR1 = -1;
    private int lastC1;
    private int lastR2;
    private int lastC2;

    //Constants 
    private static int HOLE = -1;
    private static int EMPTY = 0;

    //State Control
    private int[][] Grid; 
    private boolean gameOver;
    private int numTurns;
    private int Z; // score multiplier
    private int score;
    private int moveScore;
    private int blocksLeft;
    
    //Painting
    private Color[] colors;    
    
    protected void generate()
    {
      N = randomInt(minN, maxN);
      C = randomInt(minC, maxC);
      H = randomInt(minH, maxH);
      F = randomDouble(minF, maxF);

      //Special cases
      if (seed == 1)
      {
        N = minN;
        C = minC;
        H = minH;
        F = minF;
      }
      else if (seed == 2)
      {
        N = maxN;
        C = maxC;
        H = maxH;
        F = maxF;
      }    
      
      //User defined parameters   
      if (parameters.isDefined("N"))
        N = randomInt(parameters.getIntRange("N"), minN, maxN);
      if (parameters.isDefined("C"))
        C = randomInt(parameters.getIntRange("C"), minC, maxC);
      if (parameters.isDefined("H"))
        H = randomInt(parameters.getIntRange("H"), minH, maxH);   
      if (parameters.isDefined("F"))
        F = randomDouble(parameters.getDoubleRange("F"), minF, maxF);  

      gameOver = false;                 
      blocksLeft = 0;
      Z = N*N;
      
      //setup the grid with holes
      Grid = new int[N][N];
      for (int i=0; i<H; )
      {
        int r=randomInt(0,N-1);
        int c=randomInt(0,N-1);
        if (Grid[r][c]==EMPTY)
        {
          Grid[r][c]=HOLE;
          i++;
        }
      }

      //setup the blocks
      for (int r=0; r<N; r++)
      {
        for (int c=0; c<N; c++)
        {
          if (Grid[r][c]==EMPTY && randomDouble(0.0, 1.0)<F)
          {
            Grid[r][c] = randomInt(1, C);
            blocksLeft++;
          }
        }
      }        

      //display info
      if (debug)
      {
        System.out.println("Grid Size N = " + N);
        System.out.println("Numbers C = " + C);        
        System.out.println("Holes H = " + H);
        System.out.println("Fill rate F = " + F);
        System.out.println("Grid:");          
        for (int r=0; r<N; r++)
        {
          for (int c=0; c<N; c++)        
            System.out.print(Grid[r][c]);
          System.out.println();
        }        
      }
    }
    
    protected boolean isMaximize() {
        return true;
    }
    
    protected double run() throws Exception
    {
      init();
      if (parameters.isDefined("manual")) return 0;
      return runAuto();
    }
    
    protected double runAuto() throws Exception
    {
      String[] solution = callSolution();
      if (solution == null) {
        if (!isReadActive()) return getErrorScore();
        return fatalError();
      }
      score = 0;

      int n = solution.length;        
      if (n>N*N) return fatalError("You cannot use more than "+(N*N)+" turns");

      if (hasVis() && hasDelay()) 
      {
        updateDelay();
      }    

      for (int i=0; i<n; i++)
      {
          String[] temp=solution[i].split(" ");
          if (temp.length!=4) return fatalError("Invalid format of "+i+"th turn: "+solution[i]);

          int r, c;
          char turnType='.', direction='.';
          try
          {
              r = Integer.parseInt(temp[0]);
              c = Integer.parseInt(temp[1]);
              if (r<0 || r>=N) return fatalError("Row index "+r+" is out of bounds");
              if (c<0 || c>=N) return fatalError("Column index "+c+" is out of bounds");
              if (Grid[r][c]==EMPTY || Grid[r][c]==HOLE) return fatalError("The cell must contain a block. You are trying to move an empty cell or hole");
              if (temp[2].length()==1) turnType = temp[2].charAt(0);
              if (temp[3].length()==1) direction = temp[3].charAt(0);             
              if (turnType!='M' && turnType!='S') return fatalError("Invalid turn type ["+temp[2]+"]. Must be M or S");
              if (direction!='U' && direction!='D' && direction!='L' && direction!='R') return fatalError("Invalid direction ["+temp[3]+"]. Must be U, D, L or R");
          }
          catch (Exception e)
          {
              return fatalError("Invalid format of "+i+"th move: "+solution[i]);
          } 
          if (direction=='U') makeMove(r, c, -1, 0, turnType=='S');
          else if (direction=='D') makeMove(r, c, +1, 0, turnType=='S');
          else if (direction=='L') makeMove(r, c, 0, -1, turnType=='S');
          else if (direction=='R') makeMove(r, c, 0, +1, turnType=='S');
      }

      return score;    
    }    

    protected void updateState()
    {
      if ((numTurns>=0 || lastR1 != -1) && hasVis() && (hasDelay() || !gameOver)) 
      {      
        synchronized (updateLock) 
        {
          addInfo("Turns", numTurns);
          addInfo("Score multiplier", Z);
          addInfo("Score", score);
          addInfo("Time", getRunTime());
        }
        updateDelay();
      }
    }

    protected void contentClicked(double x, double y, int mouseButton, int clickCount)
    {
      if (!parameters.isDefined("manual")) return;
      if (gameOver) return;             //game is over
      
      int r=(int)Math.floor(y);
      int c=(int)Math.floor(x);
      if (!inGrid(r,c)) return;         //not in grid

      //click
      if (mouseButton == java.awt.event.MouseEvent.BUTTON1)
      {
        //first click must be a block
        if (lastR1==-1)
        {
          if (Grid[r][c]==EMPTY || Grid[r][c]==HOLE) return;
          
          lastR1 = r;
          lastC1 = c;
          update();
        }
        //second click must be the last location or in U,D,L,R direction
        else
        {
          if (r==lastR1 && c==lastC1)
          {
            //undo
            lastR1 = lastC1 = -1;
            update();
          }
          else
          {
            if (r!=lastR1 && c!=lastC1) return;
            lastR2 = r;
            lastC2 = c;            

            makeMove(lastR1, lastC1, Integer.signum(lastR2-lastR1), Integer.signum(lastC2-lastC1), 
              Math.abs(lastR2-lastR1)>=2 || Math.abs(lastC2-lastC1)>=2);
          }
        }
      }
    }    
    
    protected void timeout()
    {
      addInfo("Score", "-1 (Timeout)");
      addInfo("Time", getRunTime());
      update();
    }    
    
    protected boolean inGrid(int r, int c)
    {
      return (r>=0 && r<N && c>=0 && c<N);
    }
    
    private void makeMove(int r1, int c1, int dr, int dc, boolean slide) 
    {
      moveScore = 0;
      
      lastR1 = r1;
      lastC1 = c1;
      updateState();      

      //move block
      int r = r1;
      int c = c1;
      int block = Grid[r][c];
      while (inGrid(r+dr, c+dc) && Grid[r+dr][c+dc]<=EMPTY)
      {
        Grid[r][c] = EMPTY;
        r += dr;
        c += dc;
        if (Grid[r][c]==HOLE)
        {
          moveScore += Z*(block-1);
          blocksLeft--;
          break;
        }
        Grid[r][c] = block;
        if (!slide) break;
        if (!parameters.isDefined("fastMove"))
        {
          updateState(); 
        }
      }

      numTurns++;
      score+=moveScore;
      Z--;

      updateState();

      if (blocksLeft==0) gameOver=true;
    }
    
 
    private String[] callSolution() throws Exception
    {
      writeLine(N);
      writeLine(C);
      writeLine(H);
      //write grid
      for (int r=0; r<N; r++)
        for (int c=0; c<N; c++)        
          writeLine(""+Grid[r][c]); 
      flush();
      if (!isReadActive()) return null;

      startTime();
      int n = readLineToInt(-1);
      if (n <= 0) {
          setErrorMessage("Invalid number of turns: " + getLastLineRead());
          return null;
      }
      String[] ret = new String[n];
      for (int i = 0; i < ret.length; i++)
          ret[i] = readLine();
      stopTime();

      return ret;
    }
     

    protected void paintContent(Graphics2D g)
    {      
      adjustFont(g, Font.SANS_SERIF, Font.PLAIN, String.valueOf("1"), new Rectangle2D.Double(0, 0, 0.5, 0.5));        
      g.setStroke(new BasicStroke(0.005f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
    
      //draw grid      
      for (int r = 0; r < N; r++)
        for (int c = 0; c < N; c++)
        {
            g.setColor(Color.white);
            g.fillRect(c, r, 1, 1);
            g.setColor(Color.gray);       
            g.drawRect(c, r, 1, 1);
        }      
     
      //draw grid
      for (int r = 0; r < N; r++)
        for (int c = 0; c < N; c++)
        {
          if (Grid[r][c]==HOLE)
          {
            g.setColor(Color.black);
            Ellipse2D t = new Ellipse2D.Double(c + 0.1, r + 0.1, 0.8, 0.8);
            g.fill(t);              
          }
          else if (Grid[r][c]>0)
          {
            g.setColor(colors[Grid[r][c]-1]);
            g.fillRect(c, r, 1, 1);
            if (Grid[r][c]>1)
            {
              g.setColor(Color.black);   
              drawString(g, String.valueOf(Grid[r][c]), new Rectangle2D.Double(c+0.5, r+0.5, 0, 0)); 
            }
          }
        }
        
      //draw selection squares
      if (lastR1!=-1)
      {
        g.setColor(Color.red);
        g.setStroke(new BasicStroke(0.05f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawRect(lastC1, lastR1, 1, 1);
      }
      if (lastR2!=-1)
      {
        g.setColor(Color.red);
        g.setStroke(new BasicStroke(0.05f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawRect(lastC2, lastR2, 1, 1);
      }
      
    }

    private void init()
    {
      numTurns = 0;
      score = 0;  
      moveScore = 0;
      if (hasVis())
      {
        colors = new Color[] {Color.black,Color.cyan,Color.green,Color.blue,Color.orange,Color.magenta,Color.red,Color.pink,Color.gray};           
      
        lastR1 = lastC1 = lastR2 = lastC2 = -1;
        setContentRect(0, 0, N, N);
        setInfoMaxDimension(18, 10); 
        setDefaultDelay(200);

        addInfo("Seed", seed);
        addInfoBreak();
        addInfo("Size N", N);
        addInfo("Numbers C", C);
        addInfo("Holes H", H);
        addInfoBreak();           
        addInfo("Turns", numTurns);
        addInfo("Score multiplier", Z);
        addInfo("Score", 0);
        addInfoBreak();
        addInfo("Time", 0);
        update();
      }
    }
    
    public static void main(String[] args) {
        new MarathonController().run(args);
    }
}